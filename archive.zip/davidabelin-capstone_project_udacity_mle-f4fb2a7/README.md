# Capstone Project for MLE course at Udacity
repository name: capstone_project_udacity_mle

proposal.pdf contains the proposal submitted for the capstone project. 
It includes links to other material, and some images and graphs.
